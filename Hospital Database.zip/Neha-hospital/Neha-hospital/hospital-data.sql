Insert Into physician(physicianNumber, name, address, fieldOfExpertise, phoneNum, certificateNumber) values
('PHY001', 'Dr. Greeshma Palanki', '216 Barton Creek Dr, Charlotte USA', 'Cardiology', 1036862901, 'CER001'),
('PHY002', 'Dr. Neha Galla', '240 Barton Creek Dr, Rayleigh USA', 'Oncology', 1567859083, 'CER002'),
('PHY003', 'Dr. Nandini Chalicham', '9305 University center, Asheville USA', 'Pediatrics', 1678945267, 'CER003'),
('PHY004', 'Dr. Naveena Surakanti', '220 Barton Creek Dr, Asheboro USA', 'Neurology', 1234567864, 'CER004'),
('PHY005', 'Dr. Sahithya Alladi', '234 Barton Creek Dr, Anytown USA', 'Dermatology', 1986544790, 'CER005');

Select * from physician;

Insert into rooms(roomNumber, capacity, feePerNight) values
(200, 4, 500.00),
(201, 3, 800.00),
(202, 2, 900.00),
(203, 1, 950.00),
(204, 3, 800.00);

Select * from rooms;

Insert into patient(name, patientNumber, patientAddress, phoneNum, roomNumber, physicianNumber) values 
('Meghana Gayam', 'PT001', '114 south park, Denton USA', 1645908723,200, 'PHY001'),
('Akhila chilukuri', 'PT002', '220 Northlake, Asheville USA',1456378903,202, 'PHY002'),
('Ajith Babu', 'PT003','984 Oak St, Greenville USA',1456738903,	201, 'PHY003'),
('Bharath Padigala','PT004', '569 Apple St, South blvd USA',1908653478,203, 'PHY004'),
('Anvitha Gali', 'PT005','984 Brown St, Franklin USA',1456789034,204, 'PHY005');

Select * from patient;

Insert into healthRecord(patientNumber, description, date, status, diseaseHistory)
values
('PT001', 'Patient is recovering from heart surgery.', '2022-02-05', 'Recovering', 'Family history of heart disease'),
('PT002', 'Patient is undergoing chemotherapy.', '2022-05-15', 'Ongoing', 'Previous cancer diagnosis'),
('PT003', 'Patient has a broken leg.', '2022-12-08', 'Recovering', 'No significant medical history'),
('PT004', 'Patient is being treated for migraines.', '2022-04-20', 'Ongoing', 'Family history of migraines'),
('PT005', 'Patient has a skin rash.', '2022-08-10', 'Recovering', 'No significant medical history');

Select * from healthRecord;

Insert into payments (paymentId, patientNumber, amount, date, roomNumber) values
('P001', 'PT001', 30000.00, '2022-05-20', 201),
('P002', 'PT002', 45000.00, '2022-05-19', 204),
('P003', 'PT003', 42000.00, '2022-05-29', 200),
('P004', 'PT004', 15000.00, '2022-05-30', 203),
('P005', 'PT005', 39000.00, '2022-05-11', 202);

Select * from payments;

Insert into nurse (nurseNumber, name, certificateNumber, address, phoneNum, physicianNumber) values
('NR001', 'Sita Pamela', 'CN001', '123 Main St, Greensboro USA', 1267894560, 'PHY001'),
('NR002', 'Ali Ahamad', 'CN002', '456 Elm St, New jersey USA', 1563490389, 'PHY002'),
('NR003', 'Anasuya vikram', 'CN003', '789 Oak St, Uptown USA', 1346728964, 'PHY003'),
('NR004', 'Nilima kasthuri', 'CN004', '321 Maple St, South Park USA',17845093, 'PHY004'),
('NR005', 'Nirupam vachav', 'CN005', '654 Pine St, Lake South USA',1673409845, 'PHY005');

select * from nurse;

Insert into instructions (instructionCode, fees, description, physicianNumber, paymentId, nurseNumber) values
('I001', 500.00, 'Post-operation checkup', 'PHY001', 'P001', 'NR001' ),
('I002', '700', 'Physical therapy sessions', 'PHY002', 'P002', 'NR002'),
('I003', 600.00, 'Monthly health checkup', 'PHY003', 'P003', 'NR003'),
('I004', 900.00, 'Weekly consultation', 'PHY004', 'P004', 'NR004'),
('I005', 1000.00, 'Mental health therapy', 'PHY005', 'P005', 'NR005');

Select * from instructions;

Insert into medications (name, amount, nurseNumber, patientNumber) values
('Ibuprofen', 50.00, 'NR001', 'PT001'),
('Aspirin', 30.00, 'NR002', 'PT002'),
('Acetaminophen', 25.00, 'NR003', 'PT003'),
('Penicillin', 100.00, 'NR004', 'PT004'),
('Amoxicillin', 80.00, 'NR005', 'PT005');

Select * from medications;