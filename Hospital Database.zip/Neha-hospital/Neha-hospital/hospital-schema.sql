DROP DATABASE IF EXISTS hospital;
CREATE DATABASE hospital;
USE hospital;

#Table Creation
Drop Table if Exists physician Cascade;
create table physician(
	physicianNumber char(50) not null,
    Name varchar(100) not null,
    address varchar(100),
    fieldOfExpertise varchar(100),
    phoneNum int,
    certificateNumber char(50),
    primary key (physicianNumber)
);

Drop Table if Exists rooms Cascade;
create table rooms(
	roomNumber int not null,
    capacity int,
    feePerNight decimal(5,2),
    primary key(roomNumber)
);

Drop Table if Exists patient Cascade;
create table patient (
	name varchar(100) not null,
	patientNumber  char(50) not null,
	patientAddress varchar(100),
	phoneNum int,
    roomNumber int not null,
    physicianNumber char(50) not null,
	primary key (patientNumber),
    foreign key (physicianNumber) references physician(physicianNumber),
    foreign key (roomNumber) references rooms(roomNumber)
);

Drop Table if Exists healthRecord Cascade;
create table healthRecord(
 patientNumber char(50) not null,
 description varchar(200),
 date date,
 status char(10),
 diseaseHistory varchar(45),
 primary key(patientNumber),
 foreign key (patientNumber) references patient(patientNumber)
);

Drop Table if Exists payments Cascade;
create table payments(
	paymentId char(10) not null,
	patientNumber char(50) not null,
    amount decimal(10,2),
    date date,
    roomNumber int not null,
    primary key(paymentId),
    foreign key (patientNumber) references patient(patientNumber),
    foreign key (roomNumber) references rooms(roomNumber)
);

Drop Table if Exists nurse Cascade;
create table nurse(
	nurseNumber char(50) not null,
    name varchar(30) not null,
    certificateNumber varchar(45),
    address varchar(45),
    phoneNum int,
    physicianNumber char(50) not null,
    primary key(nurseNumber),
    foreign key (physicianNumber) references physician(physicianNumber)
);

Drop Table if Exists instructions Cascade;
create table instructions(
	instructionCode char(10) not null,
    fees decimal(10, 2),
    description varchar(100),
    physicianNumber char(50) not null,
    paymentId char(10) not null,
    primary key(instructionCode),
    nurseNumber char(50) not null,
    foreign key(nurseNumber) references nurse(nurseNumber),
	foreign key(paymentId) references payments(paymentId),
    foreign key (physicianNumber) references physician(physicianNumber)
);

Drop Table if Exists medications Cascade;
create table medications(
    name varchar(30) not null,
    amount decimal(10,2),
    nurseNumber char(50) not null,
    patientNumber char(50) not null,
    primary key(patientNumber),
    foreign key (nurseNumber) references nurse(nurseNumber),
    foreign key (patientNumber) references patient(patientNumber)
);















